a=[12,1,6,3,9]
print("the given array is:")
for i in range(len(a)):
    print("%d" %a[i])

for i in range(len(a)):
     
    min_val=i
     
    for j in range(i+1, len(a)):
        if a[min_val]>a[j]:
            min_val=j
             
             
             
    a[i],a[min_val]=a[min_val],a[i]
    

print("sorted array is:")
for i in range(len(a)):
    print("%d" %a[i])
    